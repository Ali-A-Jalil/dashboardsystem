import React from 'react';

const InvoicesList = () => {
    return (
        <div>
            <h1>InvoicesList</h1>
            <p>This is a placeholder for the InvoicesList page.</p>
        </div>
    );
}

export default InvoicesList;
