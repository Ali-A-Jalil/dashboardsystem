import React from 'react';

const Forecasts = () => {
    return (
        <div>
            <h1>Forecasts</h1>
            <p>This is a placeholder for the Forecasts page.</p>
        </div>
    );
}

export default Forecasts;
