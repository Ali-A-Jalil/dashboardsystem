import React from 'react';

const ProductView = () => {
    return (
        <div>
            <h1>ProductView</h1>
            <p>This is a placeholder for the ProductView page.</p>
        </div>
    );
}

export default ProductView;
