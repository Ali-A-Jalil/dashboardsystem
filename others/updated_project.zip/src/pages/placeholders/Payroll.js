import React from 'react';

const Payroll = () => {
    return (
        <div>
            <h1>Payroll</h1>
            <p>This is a placeholder for the Payroll page.</p>
        </div>
    );
}

export default Payroll;
