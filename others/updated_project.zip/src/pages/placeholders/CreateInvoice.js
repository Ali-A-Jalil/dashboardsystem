import React from 'react';

const CreateInvoice = () => {
    return (
        <div>
            <h1>CreateInvoice</h1>
            <p>This is a placeholder for the CreateInvoice page.</p>
        </div>
    );
}

export default CreateInvoice;
