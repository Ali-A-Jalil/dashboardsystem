import React from 'react';

const OldMessages = () => {
    return (
        <div>
            <h1>OldMessages</h1>
            <p>This is a placeholder for the OldMessages page.</p>
        </div>
    );
}

export default OldMessages;
