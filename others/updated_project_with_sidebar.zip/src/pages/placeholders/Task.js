import React from 'react';

const Task = () => {
    return (
        <div>
            <h1>Task</h1>
            <p>This is a placeholder for the Task page.</p>
        </div>
    );
}

export default Task;
