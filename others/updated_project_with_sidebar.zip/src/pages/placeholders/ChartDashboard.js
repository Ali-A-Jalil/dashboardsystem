import React from 'react';

const ChartDashboard = () => {
    return (
        <div>
            <h1>ChartDashboard</h1>
            <p>This is a placeholder for the ChartDashboard page.</p>
        </div>
    );
}

export default ChartDashboard;
