import React from 'react';

const NewMessages = () => {
    return (
        <div>
            <h1>NewMessages</h1>
            <p>This is a placeholder for the NewMessages page.</p>
        </div>
    );
}

export default NewMessages;
