import React from 'react';

const UpcomingReminders = () => {
    return (
        <div>
            <h1>UpcomingReminders</h1>
            <p>This is a placeholder for the UpcomingReminders page.</p>
        </div>
    );
}

export default UpcomingReminders;
