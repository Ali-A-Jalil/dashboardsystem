import React from 'react';

const OrderList = () => {
    return (
        <div>
            <h1>OrderList</h1>
            <p>This is a placeholder for the OrderList page.</p>
        </div>
    );
}

export default OrderList;
