import React from 'react';

const Employee = () => {
    return (
        <div>
            <h1>Employee</h1>
            <p>This is a placeholder for the Employee page.</p>
        </div>
    );
}

export default Employee;
