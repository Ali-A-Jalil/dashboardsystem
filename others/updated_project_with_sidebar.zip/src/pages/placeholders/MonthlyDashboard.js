import React from 'react';

const MonthlyDashboard = () => {
    return (
        <div>
            <h1>MonthlyDashboard</h1>
            <p>This is a placeholder for the MonthlyDashboard page.</p>
        </div>
    );
}

export default MonthlyDashboard;
